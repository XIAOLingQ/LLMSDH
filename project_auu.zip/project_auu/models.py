## models.py

import sqlite3
from typing import List, Tuple, Any
from utils import handle_error

class Database:
    def __init__(self, db_path: str = 'app.db'):
        """
        Initializes the Database class with a specified database path.
        
        Args:
            db_path (str): The path to the SQLite database file (default is 'app.db').
        """
        self.connection = None
        self.db_path = db_path

    def connect(self) -> None:
        """
        Establishes a connection to the SQLite database.
        """
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.connection.row_factory = sqlite3.Row
        except sqlite3.Error as e:
            handle_error(e, "Failed to connect to the database")

    def query(self, sql: str, params: Tuple[Any, ...] = ()) -> List[sqlite3.Row]:
        """
        Executes a SQL query and returns the results.
        
        Args:
            sql (str): The SQL query to execute.
            params (Tuple[Any, ...]): The parameters to substitute in the SQL query (default is an empty tuple).
        
        Returns:
            List[sqlite3.Row]: A list of rows returned by the query.
        
        Raises:
            Exception: If the database connection is not established.
        """
        if not self.connection:
            raise Exception("Database connection not established")
        
        cursor = self.connection.cursor()
        cursor.execute(sql, params)
        return cursor.fetchall()

    def close(self) -> None:
        """
        Closes the connection to the SQLite database.
        """
        if self.connection:
            self.connection.close()
            self.connection = None

# Example usage
if __name__ == "__main__":
    db = Database()
    db.connect()
    try:
        # Example query
        results = db.query("SELECT * FROM users")
        for row in results:
            print(dict(row))
    except Exception as e:
        handle_error(e, "Error during database query")
    finally:
        db.close()
