## utils.py

import logging
from typing import Any, Dict

# Configure logging
def configure_logging(level: str = 'INFO') -> None:
    """
    Configures the logging system with a specified log level.
    
    Args:
        level (str): The log level to set (default is 'INFO').
    """
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

# Error handling utility
def handle_error(error: Exception, message: str = "An error occurred") -> Dict[str, Any]:
    """
    Handles errors by logging them and returning a standardized error response.
    
    Args:
        error (Exception): The exception that occurred.
        message (str): The error message to log and return (default is "An error occurred").
    
    Returns:
        Dict[str, Any]: A dictionary containing the error message and error type.
    """
    logging.error(f"{message}: {str(error)}")
    return {"error": message, "error_type": type(error).__name__}

# Utility function to validate input data
def validate_input(data: Dict[str, Any], required_fields: list) -> bool:
    """
    Validates input data against a list of required fields.
    
    Args:
        data (Dict[str, Any]): The input data to validate.
        required_fields (list): A list of required field names.
    
    Returns:
        bool: True if all required fields are present, False otherwise.
    """
    for field in required_fields:
        if field not in data:
            logging.warning(f"Missing required field: {field}")
            return False
    return True

# Initialize utility functions
def init_utils() -> None:
    """
    Initializes utility functions, such as configuring logging.
    """
    configure_logging()

# Example usage
if __name__ == "__main__":
    init_utils()
    try:
        # Simulate an error for demonstration purposes
        raise ValueError("Invalid value provided")
    except Exception as e:
        error_response = handle_error(e)
        print(error_response)
